JLC_BOM_Compare:嘉立创元器件库的元器件号选型
bom.csv:bom单